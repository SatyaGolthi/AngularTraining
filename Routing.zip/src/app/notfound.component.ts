import { Component } from '@angular/core';

@Component({
    template:`<div class="well">
        <h1>Component Not Found</h1>
    </div>`
})
export class NotFoundComponent{}