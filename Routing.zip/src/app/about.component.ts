import { Component } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
    selector:'app-about',
    template:`<div class="well">
        <h1>About Component</h1>
        <hr>
        <div> Data passed as the Path Parameter value: {{ pathParameterId }}</div>
        <hr>
        <button class="btn btn-success" (click)="navigateToHome()">Goto to Home Component</button>
    </div>`
})
export class AboutComponent{
    pathParameterId:number;
    constructor(private activatedRoute:ActivatedRoute,private router:Router){

    }

    ngOnInit(){
        this.activatedRoute.params.subscribe((params:Params)=>{
            this.pathParameterId = parseInt(params['id']);
        });
    }

    navigateToHome(){
        this.router.navigate(['/home']);
    }
}