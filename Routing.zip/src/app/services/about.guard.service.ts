import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable()
export class AboutGuardService implements CanActivate {
    constructor(private router: Router) {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        var data: string = route.params['id'];
        var regex = /^\d+$/;

        if (parseInt(data) > 0 && data.match(regex) && !isNaN(parseInt(data))) {
            return true;
        } else {
            this.router.navigate(['\home']);
            return false;
        }
    }
}