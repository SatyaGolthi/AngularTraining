import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { appRoutes } from './app.routes';
import { AboutGuardService } from './services/about.guard.service';

@NgModule({
    imports:[RouterModule.forRoot(appRoutes)],
    exports:[RouterModule],
    providers:[AboutGuardService]
})
export class AppRouteModule{}