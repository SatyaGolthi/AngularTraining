import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    templateUrl: 'app.component.html'
})
export class AppComponent {
    id:number;

    constructor(){
        this.id = 100;
    }

    
}