import { Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { AboutComponent } from './about.component';
import { NotFoundComponent } from './notfound.component';
import { ContactComponent } from './contact/contact.component';
import { contactRoutes } from './contact/contact.routes';
import { AboutGuardService } from './services/about.guard.service';

export const appRoutes: Routes = [
    { path: '', redirectTo: 'home', pathMatch:'full' },
    { path: 'home', component: HomeComponent }, //http://localhost:4200/home
    { path: 'about/:id', canActivate:[AboutGuardService] ,component: AboutComponent }, //http://localhost:4200/about
    { path: 'contact', component: ContactComponent, children:contactRoutes }, //http://localhost:4200/contact
    { path:'**', component: NotFoundComponent}
]