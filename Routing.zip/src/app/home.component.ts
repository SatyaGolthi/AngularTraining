import { Component } from '@angular/core';

@Component({
    selector:'app-home',
    template:`<div class="well">
        <h1>Home Component</h1>
    </div>`
})
export class HomeComponent{}