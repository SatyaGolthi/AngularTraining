import { Component } from '@angular/core';

@Component({
    template:`<div class="well">
        <h1>Temporary Component</h1>
    </div>`
})
export class TemporaryComponent{}