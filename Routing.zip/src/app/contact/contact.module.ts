import { NgModule } from '@angular/core';
import { ContactRouteModule } from './contact.route.module';
import { PermanentComponent } from './permanent.component';
import { TemporaryComponent } from './temporary.component';
import { CommonModule } from '@angular/common';

@NgModule({
    imports: [CommonModule, ContactRouteModule],
    declarations: [PermanentComponent, TemporaryComponent],
    exports: [ContactRouteModule]
})
export class ContactModule { }