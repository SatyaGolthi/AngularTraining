import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { contactRoutes } from './contact.routes';

@NgModule({
    imports:[RouterModule.forRoot(contactRoutes)],
    exports:[RouterModule]
})
export class ContactRouteModule{}